# Online-exam-system

Online examination system is a app for setup online quiz with so many functionality.
It is a PHP project.


Instalation ::

### Steps

1)Copy full folder in your web directory.

2)Import database in your phpmyadmin named project1.sql.

3)Edit dbconnection file.change username,password and database name.
- Default user is root,password is null and database name is project1.

Default admin email id is head@gmail.com and password is head .
admin password is md5 encypted.






